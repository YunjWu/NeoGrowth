test_that("this works", {
  expect_equal(BW_calculation_fromWTPNA(1800,23,0), 1439.81)
})


