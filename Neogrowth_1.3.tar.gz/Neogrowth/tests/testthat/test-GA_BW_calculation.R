test_that("GA calculation works", {
  expect_equal(GA_calculation(800,0), 26.07963)
})

test_that("BW calculation works", {
  expect_equal(round(BW_calculation(42,1),3),4014.451)
})
