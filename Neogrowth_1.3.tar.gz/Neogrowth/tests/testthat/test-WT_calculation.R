# GA=42
# PNA=0
# SEX=0
# # x <- data.table::data.table(GA=40,PNA=PNA,WT=NA)[,PMA:=GA+PNA/7]
# if(SEX==0) preM <- M_Output_f_G
# if(SEX==1) preM <- M_Output_f_B
# # #calculate the percentage of difference in birthweight, for GA>42weeks, they are not assumed to follow the same wt at 43weeks of PMA
# # per_BW=BW_calculation(GA,SEX)/BW_calculation(40,SEX)
# WT <- as.numeric(predict(preM$`40`,x))*per_BW

test_that("WT_calculation works", {
  expect_equal(round(WT_calculation(42,0,0)), 3778)
})

# # library(Neogrowth)
# library(data.table)
# library(tidyverse)
# # ##
# GA <-seq(24,40)
# PNA <- seq(0,365,0.5)
# test <- data.table(GA=rep(GA,each=length(PNA)),WT=NA_real_,PNA=rep(PNA,times=length(GA)))
# test[,WT0:=mapply(WT_calculation,GA,PNA,0)]
# test[,WT1:=mapply(WT_calculation,GA,PNA,1)]
# test[,PMA:=GA+PNA/7]
# test$GA_P <- cut(test$GA,c(-Inf,25:40,Inf),include.lowest = T, right = F, c(paste0(24:40,"weeks")),ordered_result=T)
#
# #insert observations
# obs <- fread("J:/Workgroups/FWN/LACDR/PHARMACOLOGIE/Y.W/YW04_GFR_children/02_Scripts_to_make_the_dataset/GTV_final_roos_final_ImputedGABWSEX.prn")
# obs$GA_P <- cut(obs$GA,c(-Inf,25:40,Inf),include.lowest = T, right = F, c(paste0(24:40,"weeks")),ordered_result=T)
# obs[,PMA:=GA+AGEW]
# # ggplot(test)+
# #   geom_point(data=obs[SEX==1],aes(PMA,BW,color=GA_P),alpha=0.1)+
# #   geom_line(aes(PMA,WT1,group=GA,color=(GA_P)),lwd=2)+
# #   xlim(20,50)+ylim(200,10000)+guides(color = guide_legend(title = "GA"))+theme_bw(base_size = 20)+geom_vline(xintercept = 50)#+xlim(0,39)#+ylim(400,5000)#+facet_wrap(~GA)
#
# #plot by PNA for different SEX
# a <- ggplot(test)+labs(subtitle = "A: boy")+
#   geom_point(data=obs[SEX==1],aes(AGEW*7,BW,color=GA_P),alpha=0.1)+xlab("Postnatal age(days)")+ylab("Current weight (g)")+
#   geom_line(data=test,aes(PNA,WT1,group=GA,color=(GA_P)),lwd=1)+
#   xlim(0,365)+ylim(200,10000)+guides(color = guide_legend(title = "GA"))+theme_bw(base_size = 20)#+geom_vline(xintercept = 43)#+xlim(0,39)#+ylim(400,5000)#+facet_wrap(~GA)
#
# b <- ggplot(test)+labs(subtitle = "B: girl")+
#   geom_point(data=obs[SEX==0],aes(AGEW*7,BW,color=GA_P),alpha=0.1)+xlab("Postnatal age(days)")+ylab("Current weight (g)")+
#   geom_line(data=test,aes(PNA,WT0,group=GA,color=(GA_P)),lwd=1)+
#   xlim(0,365)+ylim(200,10000)+guides(color = guide_legend(title = "GA"))+theme_bw(base_size = 20)#+geom_vline(xintercept = 43)#+xlim(0,39)#+ylim(400,5000)#+facet_wrap(~GA)
#
# g_legend<-function(a.gplot){
#   tmp <- ggplot_gtable(ggplot_build(a.gplot))
#   leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
#   legend <- tmp$grobs[[leg]]
#   return(legend)}
# mylegend<-g_legend(a)
# library(gridExtra)
# grid.arrange(arrangeGrob(a + theme(legend.position="none"),
#                                    b + theme(legend.position="none"),mylegend,
#                                    nrow = 1,widths = c(6,6,1.5))
#   )
#
# #check the distribution
# #test[,p90_1:=mapply(quantile,mapply(WT_calculation_dist,GA,PNA,1,1000), 0.90, na.rm = T)]
#
# test$p90_1 <- map2_dbl(test$GA,test$PNA, function(x,y) WT_calculation_percentile(x,y,1,0.90))
# test$p10_1 <- map2_dbl(test$GA,test$PNA, function(x,y) WT_calculation_percentile(x,y,1,0.1))
#
# test$p90_0 <- map2_dbl(test$GA,test$PNA, function(x,y) WT_calculation_percentile(x,y,0,0.90))
# test$p10_0 <- map2_dbl(test$GA,test$PNA, function(x,y) WT_calculation_percentile(x,y,0,0.1))
#
# a=ggplot(test)+labs(subtitle = "A: boy")+
#   geom_point(data=obs[SEX==1],aes(PMA,BW,color=GA_P),alpha=0.1)+xlab("Postmenstrual age(weeks)")+ylab("Current weight (g)")+
#   geom_line(aes(PMA,WT1,group=GA,color=(GA_P)),lwd=2)+
#   geom_line(aes(PMA,p90_1,group=GA,color=GA_P),lwd=1,lty=2)+
#   geom_line(aes(PMA,p10_1,group=GA,color=GA_P),lwd=1,lty=2)+
#   xlim(20,60)+ylim(200,10000)+
#   guides(color = guide_legend(title = "GA"))+theme_bw(base_size = 20)#+xlim(0,39)#+ylim(400,5000)#+facet_wrap(~GA)
#
# b=ggplot(test)+labs(subtitle = "B: girl")+
#   geom_point(data=obs[SEX==0],aes(PMA,BW,color=GA_P),alpha=0.1)+xlab("Postmenstrual age(weeks)")+ylab("Current weight (g)")+
#   geom_line(aes(PMA,WT0,group=GA,color=(GA_P)),lwd=2)+
#   geom_line(aes(PMA,p90_0,group=GA,color=GA_P),lwd=1,lty=2)+
#   geom_line(aes(PMA,p10_0,group=GA,color=GA_P),lwd=1,lty=2)+
#   xlim(20,60)+ylim(200,10000)+
#   guides(color = guide_legend(title = "GA"))+theme_bw(base_size = 20)#+xlim(0,39)#+ylim(400,5000)#+facet_wrap(~GA)
#
# g_legend<-function(a.gplot){
#   tmp <- ggplot_gtable(ggplot_build(a.gplot))
#   leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
#   legend <- tmp$grobs[[leg]]
#   return(legend)}
#
# mylegend<-g_legend(a)
# library(gridExtra)
# grid.arrange(arrangeGrob(a + theme(legend.position="none"),
#                          b + theme(legend.position="none"),mylegend,
#                          nrow = 1,widths = c(6,6,1.5))
# )
