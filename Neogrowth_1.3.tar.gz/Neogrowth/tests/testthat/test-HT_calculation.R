test_that("HT works", {
  expect_equal(round(HT_calculation(56,0)), 61)
})
