.datatable.aware=TRUE

#' calculate the weight based on GA PNA and SEX
#'
#' @param GA_weeks
#' @param PNA_day
#' @param SEX_0_girl_1_boy
#'
#' @return current weight in g
#' @export
#'
#' @examples WT_calculation(42,0,0)
WT_calculation <- function(GA_weeks,PNA_day,SEX0F1M){
  if(is.na(GA_weeks)|is.na(PNA_day)|is.na(SEX0F1M)){
    return(NA)
  }else{
    GA <- GA_weeks
    PNA <- PNA_day
    SEX <- SEX0F1M
    if(SEX==0) preM <- M_Output_f_G
    if(SEX==1) preM <- M_Output_f_B
    if(GA+PNA/7<50){ #if less than 50 weeks of PMA,
      BW <- BW_calculation(GA,SEX)
      if(GA<=40){# if GA< 40 week,need to impute the WT in between each available GA with the same PNA
        oo <- as.numeric(names(preM))
        dt = data.table::data.table(oo, val = oo)
        #data.table::setattr(dt, "sorted", "oo")  # let data.table know that w is sorted
        data.table::setkey(dt, oo) # sorts the data
        #key(dt)
        minGA <- dt[J(GA), roll =T]$val
        maxGA <- dt[J(GA), roll = -Inf]$val
        h <- data.table::data.table(GA=c(minGA,maxGA),PNA=PNA,SEX=SEX,WT=NA)[,PMA:=GA+PNA/7]
        for (i in 1:length(h$GA)) {
          GAi=h$GA[i]
          pre <- preM[[as.character(GAi)]]
          h$WT[i]=as.numeric(predict(pre,h[i,]))
        }
        WT_min <-unique(h[GA==minGA]$WT)
        WT_max <- unique(h[GA==maxGA]$WT)
        PER <- ifelse(WT_min==WT_max,0,
                      (BW-BW_calculation(minGA,SEX))/(BW_calculation(maxGA,SEX)-BW_calculation(minGA,SEX))
        )
        WT <- WT_min+(WT_max-WT_min)*PER
      }else{
        x <- data.table::data.table(GA=GA,PNA=PNA,WT=NA)[,PMA:=GA+PNA/7]
        #calculate the percentage of difference in birthweight, for GA>42weeks, they are assumed to follow the same drop
        x1 <- data.table::data.table(GA=40,PNA=PNA,WT=NA)[,PMA:=GA+PNA/7]
        x[,per_BW:=as.numeric(predict(preM$`40`,x1))/BW_calculation(40,SEX)]
        x[,WT:=as.numeric(predict(preM$`40`,x))]
        x[,WT1:=BW*per_BW]
        WT <- ifelse((x$WT1<x$WT)|PNA<4,x$WT1,x$WT)# I think need to find a way for GA above 40 weeks using birthweight
      }

    }else{
      x <- data.table::data.table(GA=GA,PNA=PNA,WT=NA)[,PMA:=GA+PNA/7]
      WT <-  as.numeric(predict(preM$`40`,x))
    }
    return(WT)
  }

}


# BW_calculation(24,0)
# WT_calculation(24,59,0)
# simulatedWT <- rBCCG(1000, mu = as.numeric(predict(M_Output_f_B$`31`,data.table(PMA=32)))/1000,
#                      sigma =as.numeric(predict(L_Output_f_B, data.table(PNA=32))),
#                      nu =as.numeric(predict(S_Output_f_B, data.table(PNA=32))))
# hist(WT_calculation_sim(38,0,0,1000))
#
# test <- data.table(GA=24,PNA=c(0:300),SEX=0)[,PMA:=GA+PNA/7]
# #test <- test[,.(PMA)]
# test[,WT:=mapply(WT_calculation,GA,PNA,0)]
# test[,WT:=predict(M_Output_f_G[['24']],test)]
# test[,L:=predict(L_Output_f_G,test)]
# ggplot(test,aes(PNA,WT))+geom_point()
# s <- splines::predict(M_Output_f_B$`31`,32)
# require(stats)
# basis <- ns(women$height, df = 5)
# newX <- seq(58, 72, length.out = 51)
# # evaluate the basis at the new data
# predict(basis, newX)
