
#' Title
#'
#' @param WT_g
#' @param PNA_days
#' @param SEX0F1M
#' @param GA gestational age. provide if known. default is NA
#'
#' @return birth weight in grams
#' @export
#'
#' @examples
BW_calculation_fromWTPNA <- function(WT_g,PNA_days,SEX0F1M,GA=NA){
  if(is.na(WT_g)|is.na(PNA_days)|is.na(SEX0F1M)){
    return(NA)
    break
  }else{
    WT <- WT_g
    PNA <- PNA_days
    SEX <- SEX0F1M
    avail_GA <- as.numeric(names(M_Output_f_B))
    avail_WT <-mapply(WT_calculation, avail_GA,PNA,SEX)
    avail <- data.table::data.table(GA=avail_GA,avail_WT,obs_WT=avail_WT)
    max_avail_WT <- max(avail[,avail_WT])
    min_avail_WT <- min(avail[,avail_WT])
    if(!(WT>max_avail_WT|WT<min_avail_WT)&is.na(GA)){
      data.table::setattr(avail, "sorted", "obs_WT")  # let data.table know that w is sorted
      data.table::setkey(avail, obs_WT)
      minGA <- avail[J(WT),roll=T]$GA
      maxGA <- avail[J(WT),roll=-Inf]$GA
      minBW <- BW_calculation(minGA,SEX)
      maxBW <- BW_calculation(maxGA,SEX)
      Per <- (WT-avail[GA==minGA,avail_WT])/(avail[GA==maxGA,avail_WT]-avail[GA==minGA,avail_WT])
      calBW <- round(Per*(maxBW-minBW)+minBW,2)
      return(calBW)
      break
    }else{
      if(WT>max(avail[,avail_WT])&is.na(GA)){
        GAi <- 40
        mu=max_avail_WT/1000
        lower.tail=F
      }else if(WT<max(avail[,avail_WT])&is.na(GA)){
        GAi <- 24
        mu=min_avail_WT/1000
        lower.tail=T
      }else{
        GAi=GA
        mu=WT_calculation(GAi,PNA,SEX)/1000
      }
      if(SEX==0) preL <- L_Output_f_G
      if(SEX==1) preL <- L_Output_f_B
      if(SEX==0) preS <- S_Output_f_G
      if(SEX==1) preS <- S_Output_f_B
      sigma_WT <- as.numeric(predict(preS, data.table::data.table(PMA=GAi+PNA/7))) #the sigma value for the respective GA values and days
      nu_WT <- as.numeric(predict(preL, data.table::data.table(PMA=GAi+PNA/7)))
      cdf <- gamlss.dist::pBCCG(WT/1000,mu=mu,sigma=sigma_WT,nu=nu_WT) #calculate the cdf of the bodyweight
      sigma_BW <- as.numeric(predict(preS, data.table::data.table(PMA=GAi)))
      nu_BW <- as.numeric(predict(preL, data.table::data.table(PMA=GAi)))
      calBW <- gamlss.dist::qBCCG(cdf,mu=BW_calculation(GAi,SEX),sigma=sigma_BW,nu=nu_BW) #then inverse the cdf based on the birthweight distribution
      calBW <- round(calBW,2)
      return(calBW)
      break
    }
  }

}

