# data("GB_0")
# GA_G_fit<- lm(L~splines::bs(GA,knots=c(23,28,30,32,34,36,38,40,42,44,48),degree = 30),data = GB_0)
# data("GB_1")
# GA_B_fit<- lm(M~splines::bs(GA,knots=c(23,28,30,32,34,36,38,40,42,44,48),degree = 30),data = GB_1)
#
# BW_knot_G <- predict(GA_G_fit,data.table(GA=c(22.5,23,24,26,28,30,32,34,36,38,40,42),M=NA_real_))
# BW_G_fit<- lm(GA*100~splines::bs(M/100,knots=c(BW_knot_G,6000)/1000,degree = 40),data = GB_0)
# BW_knot_B<- predict(GA_B_fit,data.table(GA=c(22.5,28,30,32,34,36,38,40,42,44,48,50),M=NA_real_))
# BW_B_fit<- lm(GA*100~splines::bs(M/1000,knots=c(BW_knot_B,6000)/1000,degree = 30),data = GB_1)
#
# #check fit
# data=data.table(GA=(23:50),M=0)
# data[,M:=predict(GA_G_fit,data)]
# ggplot(data,aes(GA,M))+geom_line(color="red",size=3)+geom_point(data=GB_0,aes(GA,M))#+xlim(0,30)+ylim(500,1500)
# data[,M:=predict(GA_B_fit,data)]
# ggplot(data,aes(GA,M))+geom_line(color="red",size=3)+geom_point(data=GB_1,aes(GA,M))#+xlim(0,30)+ylim(500,1500)
#
