
#' Title
#'
#' @param GA_weeks
#' @param PNA_day
#' @param SEX0F1M
#' @param p percentile
#'
#' @return
#' @export
#'
#' @examples
WT_calculation_percentile <- function(GA_weeks,PNA_day,SEX0F1M,p){
  mu=WT_calculation(GA_weeks,PNA_day,SEX0F1M)/1000
  if(is.na(GA_weeks)|is.na(PNA_day)|is.na(SEX0F1M)){
    return(NA)
  }else{
    GA <- GA_weeks
    PNA <- PNA_day
    PMA=GA+PNA/7
    SEX <- SEX0F1M
    if(SEX==0) preL <- L_Output_f_G
    if(SEX==1) preL <- L_Output_f_B
    if(SEX==0) preS <- S_Output_f_G
    if(SEX==1) preS <- S_Output_f_B
    WT <- c()
    WT <- gamlss.dist::qBCCG(p, mu =mu,
                             sigma =as.numeric(predict(preS, data.table::data.table(PMA))),
                             nu =as.numeric(predict(preL, data.table::data.table(PMA))))
    print(WT*1000)
  }
}

