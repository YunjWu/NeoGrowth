##GA calculation from##############
#' Title
#'
#' @param BW_g birthweight in g
#' @param SEX0F1M
#'
#' @return GA in weeks
#' @export
#'
#' @examples GA_calculation(800,0)
GA_calculation<- function(BW_g,SEX0F1M){ #this is the function that calculate missing GA from BW
  if(is.na(BW_g)|is.na(SEX0F1M)){
    return(NA)
  }else{
    ##reference: Fenton TR, Kim JH. A systematic review and meta-analysis to revise the Fenton growth chart for preterm infants. BMC Pediatr. 2013;13:59.
    BW=BW_g
    gender=SEX0F1M
    #prepare for the dataset
    ifelse(gender==1,GB <- GB_1,
           GB <- GB_0
    )
    colnames(GB)[1] <- "GA in weeks"
    colnames(GB)[3] <- "BW in g"
    #interpolation
    c=c(GB$`BW in g`)
    c1=c(GB$`BW in g`)
    d=c(GB$`GA in weeks`)
    xx <- data.table::data.table(c,c1,d)[order(c1)][!duplicated(c1)&complete.cases(c1)]
    data.table::setkey(xx, c1) # sorts the data
    minBW <- xx[J(BW), roll = T]$c #use c instead because c1 is replaced by BW
    maxBW <- xx[J(BW), roll = -Inf]$c
    if(!(is.na(minBW)|is.na(maxBW))){
      GA=zoo::na.approx(c(xx[c1==minBW]$d,NA,xx[c1==maxBW]$d),c(minBW,BW,maxBW),rule=2,ties ="ordered")[2]
      #return BW
      return(GA)
    }else{
      return("not in the range of the function,please check")
    }
  }
}

###prepare revised fenton growth chart#####
#' Title
#'
#' @param GA_weeks
#' @param SEX0F1M
#'
#' @return Birthwight in g
#' @export
#'
#' @examples BW_calculation(42,1)
BW_calculation<- function(GA_weeks,SEX0F1M){ #this is the function that calculate missing BW from GA
  if(is.na(GA_weeks)|is.na(SEX0F1M)){
    return(NA)
  }else{
    ##reference: Fenton TR, Kim JH. A systematic review and meta-analysis to revise the Fenton growth chart for preterm infants. BMC Pediatr. 2013;13:59.
    GA=GA_weeks
    gender=SEX0F1M
    #prepare for the dataset
    ifelse(gender==1,GB <- GB_1,
           GB <- GB_0
    )
    colnames(GB)[1] <- "GA in weeks"
    colnames(GB)[3] <- "BW in g"
    ##interpolation
    c=c(GB$`GA in weeks`)
    c1=c(GB$`GA in weeks`)
    d=c(GB$`BW in g`)
    xx <- data.table::data.table(c,c1,d)
    xx <- xx[order(c1)][!duplicated(c1)&complete.cases(c1)]
    data.table::setkey(xx, c1) # sorts the data
    minGA <- xx[J(GA), roll = T]$c #use c instead because c1 is replaced by BW
    maxGA <- xx[J(GA), roll = -Inf]$c
    if(!(is.na(minGA)|is.na(maxGA))){
      BW=zoo::na.approx(c(xx[c1==minGA]$d,NA,xx[c1==maxGA]$d),c(minGA,GA,maxGA),rule=2,ties ="ordered")[2]
      #return BW
      return(BW)
    }else{
      return("not in the range of the function,please check")
    }
  }
}


