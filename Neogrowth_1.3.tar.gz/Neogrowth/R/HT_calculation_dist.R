#' Title
#'
#' @param PMA_weeks
#' @param SEX0F1M
#' @param N_HT
#'
#' @return
#' @export
#'
#' @examples
HT_calculation_dist <- function(PMA_weeks,SEX0F1M,N_HT){
  mu=HT_calculation(PMA_weeks,SEX0F1M)
  if(is.na(PMA_weeks)|is.na(SEX0F1M)){
    return(NA)
  }else if(PMA_weeks<24|PMA_weeks>1118){
    return("prediction out of range, may be incorrect")
  }else{
    PMA=PMA_weeks
    SEX <- SEX0F1M
    if(SEX==0) preS <- S_fit_H_boy
    if(SEX==1) preS <- S_fit_H_girl
    HT <- c()
    HT <- gamlss.dist::rBCCG(N_HT, mu =mu,
                             sigma =as.numeric(predict(preS, data.table::data.table(PMA))),
                             nu =1)
    print(HT)
  }
}
# HT_calculation_dist(24,0,1000)
# hist(HT_calculation_dist(24,0,1000))
