###start to fit all PMA###############################################
#M
M_Output_f_G <- list()
data("ALL_G")
ALL_G <-ALL_G %>% split(.$GA) #%>% filter(PMA<=100)
for (i in names(ALL_G)) {
  GA=as.numeric(i)
  knots=union(GA+c(1,2,3,10,20),c(50,51,60,70,90,100,200,500,600,700,1000,1100))#in this step need denser data for low PNA
  M_Output_f_G[[i]] <- lm(WT~splines::bs(PMA,knots=knots),data = ALL_G[[i]])
}


#check the prediction for PNA<60 days
# GA <- as.numeric(names(M_Output_f_G))
# PNA <- rep(seq(1,200,0.1),times=length(GA))
# GA <- rep(GA,each=length(unique(PNA)))
# sim <- data.table(GA,PNA,PMA=GA+PNA/7,WT=NA_real_)
# for (i in names(M_Output_f_G)) {
#
#   s <- predict(M_Output_f_G[[i]],  sim[GA==as.numeric(i),])
#   sim[GA==as.numeric(i),WT:=s]
# }
# AIC(M_Output_f_G[[2]])
# ggplot(sim,aes(PMA,WT,color=as.factor(GA)))+geom_point()+xlim(20,60)+ylim(0,6000)+guides(color = guide_legend(title = "GA"))+theme_bw(base_size = 20)+geom_vline(xintercept = 43)

# # #check prediction on specific GA
# Check_plot <- function(data,model){
#   name=data$GA[1]
#   ggplot(data,aes(PMA,predict(model)))+geom_line(color="red",size=3)+geom_point(aes(PMA,WT))+xlim(0,80)+ylim(500,6000)+labs(title=name)
#
# }
# map2(ALL_G,M_Output_f_G,Check_plot)

# #check the prediction for PNA>60 days
# ggplot(ALL_G$`26`,aes(PNA,predict(M_Output_f_G$'26')))+geom_line(color="red",size=3)+geom_point(aes(PNA,WT))#+xlim(0,365)+ylim(400,10000)

# #check the prediction for PNA<60 days L
#ggplot(ALL_G$`26`,aes(PNA,predict(M_Output_f_G$'26')))+geom_line(color="red",size=3)+geom_point(aes(PNA,WT))#+xlim(0,365)


#predict(Output_f_G_1[[1]],data.frame(WT=NA,PMA=40))

data("ALL_G_LS")
#L #only need one value, because they are the same for every GA
# knots=c(1,5,10,20,40.5,42,45,50,70,90,100,200,500,600,700,1000,1200)*7
knots=c(25,30,35,40.5,42,45,50,70,90,100,200,250,300,500,550,600,700,800,1000,1100)
L_Output_f_G <-ALL_G_LS%>% lm(L~splines::bs(PMA,knots=knots),data = .)

#S #only need one value, because they are the same for every GA
S_Output_f_G <-ALL_G_LS%>% lm(S~splines::bs(PMA,knots=knots),data = .)

#check the fit of L and S
# PMA=c(22.5:1200)
# L <- predict(L_Output_f_G,data.frame(PMA,L=NA_real_))
# S <- predict(S_Output_f_G,data.frame(PMA,S=NA_real_))
# simLS <- data.table(PMA,L,S)
# ggplot(simLS,aes(PMA,L))+geom_point(data =ALL_G_LS,aes(PMA,L) )+geom_line(color="red",linewidth=1)+theme_bw(base_size = 20)#+xlim(0,50)#+ylim(-5,5)
# ggplot(simLS,aes(PMA,S))+geom_point(data =ALL_G_LS,aes(PMA,S))+geom_line(color="red",linewidth=1 )+theme_bw(base_size = 20)#+xlim(0,50)#+ylim(-5,5)

##_____________________________________________________________
#boys
#M
M_Output_f_B <- list()
data("ALL_B")
ALL_B <- ALL_B %>% split(.$GA)
for (i in names(ALL_B)) {
  GA=as.numeric(i)
  knots=union(GA+c(1,2,3,10,20),c(50,51,60,70,90,100,200,500,600,700,1000,1100)) #in this step need denser data for low PNA
  M_Output_f_B[[i]] <- lm(WT~splines::bs(PMA,knots=knots),data = ALL_B[[i]])
}

data("ALL_B_LS")
#L #only need one value, because they are the same for every GA
#knots=c(1,5,10,20,40.5,42,45,50,70,90,100,200,500,600,700,1000,1200)*7
knots=c(25,30,35,40.5,42,45,50,70,90,100,200,250,300,500,550,600,700,800,1000,1100)
L_Output_f_B <-ALL_B_LS%>% lm(L~splines::bs(PMA,knots=knots),data = .)

#S #only need one value, because they are the same for every GA
S_Output_f_B <-ALL_B_LS%>% lm(S~splines::bs(PMA,knots=knots),data = .)

#check the prediction for PNA<60 days
# GA <- as.numeric(names(M_Output_f_B))
# PNA <- rep(seq(1,200,0.1),times=length(GA))
# GA <- rep(GA,each=length(unique(PNA)))
# sim <- data.table(GA,PNA,PMA=GA+PNA/7,WT=NA_real_)
# for (i in names(M_Output_f_B)) {
#
#   s <- predict(M_Output_f_B[[i]],  sim[GA==as.numeric(i),])
#   sim[GA==as.numeric(i),WT:=s]
# }
# AIC(M_Output_f_B[[2]])
# ggplot(sim,aes(PMA,WT,color=as.factor(GA)))+geom_point()+xlim(20,60)+ylim(0,8000)+guides(color = guide_legend(title = "GA"))+theme_bw(base_size = 20)+geom_vline(xintercept = 43)

# #check the prediction for PNA<60 days
# ggplot(ALL_B$`25`,aes(PNA,predict(M_Output_f_B$'25')))+geom_line(color="red",size=3)+geom_point(aes(PNA,WT))+xlim(0,60)+ylim(400,800)
#
#check prediction on specific GA
# Check_plot <- function(data,model){
#   name=data$GA[1]
#   ggplot(data,aes(PNA,predict(model)))+geom_line(color="red",size=3)+geom_point(aes(PNA,WT))+xlim(0,80)+ylim(500,6000)+labs(title=name)
#
# }
# map2(ALL_B,M_Output_f_B,Check_plot)

#check the fit of L and S
# PMA=c(22.5:1200)
# L <- predict(L_Output_f_B,data.frame(PMA,L=NA_real_))
# S <- predict(S_Output_f_B,data.frame(PMA,S=NA_real_))
# simLS <- data.table(PMA,L,S)
# ggplot(simLS,aes(PMA,L))+geom_point(data =ALL_B_LS,aes(PMA,L) )+geom_line(color="red",linewidth=1)+theme_bw(base_size = 20)#+xlim(0,50)#+ylim(-5,5)
# ggplot(simLS,aes(PMA,S))+geom_point(data =ALL_B_LS,aes(PMA,S))+geom_line(color="red",linewidth=1 )+theme_bw(base_size = 20)#+xlim(0,50)#+ylim(-5,5)
#
