###now fit the growth chart#################################
data(All_boy_HT)
M_fit_H_boy <- lm(M~splines::bs(PMA,knots = c(30,50,100,250,500,750,1000),degree = 20),data = All_boy_HT)
S_fit_H_boy <- lm(S~splines::bs(PMA,knots = c(24,30,40,50,100,250,500,750,1000),degree = 20),data = All_boy_HT)
#summary(fit_H_boy)
data(All_Girl_HT)
M_fit_H_girl <- lm(M~splines::bs(PMA,knots = c(30,50,100,250,500,750,1000),degree = 20),data = All_Girl_HT)
S_fit_H_girl <- lm(S~splines::bs(PMA,knots = c(24,30,40,50,100,250,500,750,1000),degree = 20),data = All_Girl_HT)
#check
#gplot(All_boy_HT,aes(PMA,predict(M_fit_H_boy)))+geom_line(color="red",size=3)+geom_point(aes(PMA,M))#+xlim(0,30)#+ylim(500,1500)
# ggplot(All_boy_HT,aes(PMA,predict(S_fit_H_boy)))+geom_line(color="red",size=3)+geom_point(aes(PMA,S))#+xlim(0,30)#+ylim(500,1500)
# ggplot(All_Girl_HT,aes(PMA,predict(S_fit_H_girl)))+geom_line(color="red",size=3)+geom_point(aes(PMA,S))#+xlim(0,30)#+ylim(500,1500)

# #
