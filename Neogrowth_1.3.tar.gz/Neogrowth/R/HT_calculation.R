#' Title
#'
#' @param PMA_weeks
#' @param SEX0F1M
#'
#' @return
#' @export
#'
#' @examples
HT_calculation <- function(PMA_weeks,SEX0F1M){
  if(is.na(PMA_weeks)|is.na(SEX0F1M)){
    return(NA)
  }else if(PMA_weeks<24|PMA_weeks>1118){
    return("prediction out of range, may be incorrect")
  }else{
    dt <- data.table::setDT(data.frame(M=NA,PMA=PMA_weeks))
    if(SEX0F1M==0){
      Ht <- as.numeric(predict(M_fit_H_girl,dt) )
    }else{
      Ht <- as.numeric(predict(M_fit_H_boy,dt) )
    }
    return(Ht)
  }

}

#HT_calculation(54,0)
