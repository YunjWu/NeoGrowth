bodyweight and Height growth chart v1
author:Yunjiao Wu
____________________WT_______________________
1. Extract dataset from plot
 - GA_BW
  * data/GA-BW (girl).csv (from Fenton TR, Kim JH. A systematic review and meta-analysis to revise the Fenton growth chart for preterm infants. BMC Pediatr. 2013;13:59.)
  * data/GA-BW (boy).csv (from Fenton TR, Kim JH. A systematic review and meta-analysis to revise the Fenton growth chart for preterm infants. BMC Pediatr. 2013;13:59.)
 - WT-PNA term neonates low age
  * term neonates growth chart vaginal.csv (from plot)
 - WT PNA preterm neonates low age
  * GrowthProfiles_V3_26-03-2020.csv (extracted by Aline)
 - WT PNA term high age
  * data/wfa_boys_p_0_19.csv (https://cpeg-gcep.net/sites/default/files/upload//bookfiles/WHOGrowthChartData2014.zip)
  * data/wfa_girls_p_0_19.csv (https://cpeg-gcep.net/sites/default/files/upload//bookfiles/WHOGrowthChartData2014.zip)

2. calculate BW from GA
 - function: BW_calculation, find the nearest GA in the table of the provided GA, then interpolate the BW

3. calculate GA from BW
 - function: GA_calculation, find the nearest BW in the table of the provided BW, then interpolate the GA

4. calculate WT from PMA
 - combine tha growthchart for GA<32 weeks with lower age with term neonates growthchart (data-raw/WTDATASET.R)
 - combine the growthchart for GA=40 weeks with lower age with term neonates growthchart (data-raw/WTDATASET.R)
 - use spline function to fit for each GA (R/WT_bs_fit.R)
 - function: WT_calculation, predict using pline equation and then interpolate the bodyweight for GA between 32-40 week
5. calulate BW from WT
 - use spline functions to simulate WT for each GA catorgory of available fit
 - find the weight catorgory the observed WT is in, then based on its position in the two simulated WT of the catorgaries,
   calculate the BW position.

knowledge:
spline, distribution, LMS methods

usage of this package:
1. provide virtual population
2. impute missing variable
  - assume if a patient is born with a birthweight of 70th of the GA, then it will stay at that percentile for the rest of life

next stage:
faster
calculate percentile based on provided WT
provide WT as certain percentile
get the S,L for PMA below 40 from fenton data

____________________HT________________________
1. Extract dataset from plot
 - GA_HT
  * data/Fenton_height_Boys.csv (from Fenton TR, Kim JH. A systematic review and meta-analysis to revise the Fenton growth chart for preterm infants. BMC Pediatr. 2013;13:59.)
  * data/Fenton_height_Girls.csv(from Fenton TR, Kim JH. A systematic review and meta-analysis to revise the Fenton growth chart for preterm infants. BMC Pediatr. 2013;13:59.)
 - HT-PMA 0-5
  * data-raw/lhfa-boys-percentiles-expanded-tables.xlsx (https://www.who.int/tools/child-growth-standards/standards/length-height-for-age)
  * data-raw/lhfa-girls-percentiles-expanded-tables.xlsx (https://www.who.int/tools/child-growth-standards/standards/length-height-for-age)
 - HT-PMA 5-19 year
  * data-raw/hfa-boys-z-who-2007-exp.xlsx (https://www.who.int/tools/growth-reference-data-for-5to19-years/indicators/height-for-age)
  * data-raw/hfa-girls-z-who-2007-exp.xlsx(https://www.who.int/tools/growth-reference-data-for-5to19-years/indicators/height-for-age)
  * term neonates growth chart vaginal.csv (from plot)

4. calculate HT from PMA
 - combine tha growthchart  (data-raw/HTDATASET.R)
 - function: HT_calculation, predict using pline equation (R/HT_bs_fit.R)
